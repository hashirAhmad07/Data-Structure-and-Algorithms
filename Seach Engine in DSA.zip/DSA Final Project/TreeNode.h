#ifndef TREETreeNode_H
#define TREETreeNode_H

#include<string>
#include<iostream>
using namespace std;

class TreeNode
{
    public:
        TreeNode();
        TreeNode(int,string,string);
        virtual ~TreeNode();

        int Getdata() { return data; }
        void Setdata(int val) { data = val; }
        TreeNode* Getleft() { return left; }
        void Setleft(TreeNode* val) { left = val; }
        TreeNode* GetRight() { return Right; }
        void SetRight(TreeNode* val) { Right = val; }
        void Setname(string n){ name = n; }
        string Getname() { return name; }
        void Setlocation(string n){ location = n; }
        string Getlocation() { return location; }
        void SetHeight(int val){Height=val;}
        int GetHeight(){return Height;}
    protected:

    private:
        int data;
        string name;
        string location;
        TreeNode* left;
        TreeNode* Right;
        int Height;
};
#endif // TREETreeNode_H
