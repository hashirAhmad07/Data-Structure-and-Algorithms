#ifndef HASHTABLE_H
#define HASHTABLE_H
#include<fstream>
#include"AVLTREE.h"
#include"TreeNode.h"
class Hashtable
{
    public:
        Hashtable(int);
        Hashtable();
        virtual ~Hashtable();

        AVLTREE* Getarr() { return arr; }
        void Setarr(AVLTREE* val) { arr = val; }
        int GetSize() { return Size; }
        void SetSize(int val) { Size = val; }
        int HashFunction(int);
        int HashAgain(int);
        bool isempty();
        void insertion(string,string,int);
        bool Increase_SizeOf_Table();
        bool IsBucketFull();
        bool isPrime(int);
        int nextPrime(int);
        AVLTREE* Rehash_Newtable(string,string,int);
        TreeNode* Search(int);
        void display();
        void DeleteData(int);
        void DeleteAllRecord();
        void UpdateData(int,Hashtable&);
        void printTree();
        void load_file();
        void write_file(fstream&);
        void Setfrequency(int val){Count=0;}
        int Getfrequency(){return Count;}

    protected:

    private:
        AVLTREE* arr;
        int Size;
        int Count;
        int frequency;
        bool flag;
};

#endif // HASHTABLE_H
