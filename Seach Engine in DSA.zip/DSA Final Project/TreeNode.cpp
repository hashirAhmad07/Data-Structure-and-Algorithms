#include "TreeNode.h"
#include<iostream>
using namespace std;
TreeNode::TreeNode()
{
    data=0;
    left=NULL;
    Right=NULL;

}
TreeNode::TreeNode(int val,string n,string l)
{
    data = val;
    name = n;
    location = l;
    left = NULL;
    Right = NULL;
}
TreeNode::~TreeNode()
{
    //dtor
}
