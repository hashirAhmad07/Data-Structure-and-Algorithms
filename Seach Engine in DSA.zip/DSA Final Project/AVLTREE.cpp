#include "AVLTREE.h"
#include "Hashtable.h"
#include <iostream>
#include <fstream>
#include<windows.h>

#include "TreeNode.h"
using namespace std;

AVLTREE::AVLTREE()
{
    Root = NULL;
    flag=false;
    frequency=0;
}

bool AVLTREE::isepmty()
{
    if(Root==NULL)
        return true;
    else
        return false;
}

int AVLTREE::HieghtInBST(TreeNode* root)
{
    if(root==NULL)
        return -1;
    else
    {
       int left = HieghtInBST(root->Getleft());
        int right = HieghtInBST(root->GetRight());
        int maxDept;
        if(left>right)
        {
              maxDept = 1+left;
        }
        else
        {
             maxDept = 1+right;
        }
    return maxDept;
    }

}

int AVLTREE::Maximum(int a , int b)
{
    return (a > b) ? a : b;
}

int AVLTREE::Height(TreeNode* root)
{
    if(root==NULL)
        return 0;
   return root->GetHeight();
}

int AVLTREE::GetbalanceFactor(TreeNode* root)
{
    if(root==NULL)
    {
        return -1;
    }
    return HieghtInBST(root->Getleft()) - HieghtInBST(root->GetRight());
}

TreeNode* AVLTREE::LeftRotate(TreeNode* root)
{
    TreeNode* y = root->GetRight();
    TreeNode* z = y->Getleft();

    y->Setleft(root);
    root->SetRight(z);

    return y;
}


TreeNode* AVLTREE::RightRotate(TreeNode* root)
{
    TreeNode* y = root->Getleft();
    TreeNode* z = y->GetRight();

    y->SetRight(root);
    root->Setleft(z);

    return y;
}

TreeNode* AVLTREE::Insert(TreeNode* root ,string name,string location, int val)
{
    TreeNode* newTreeNode = new TreeNode(val,name,location);
    if(GetRoot() == NULL)
    {
        if(GetRoot()==NULL)
        {
            Root=newTreeNode;
        }
        else
        root = newTreeNode;
        return root;
    }
    else if(val < root->Getdata())///if value is less than
    {
        if(root->Getleft()==NULL)
            root->Setleft(newTreeNode);
        else
           root->Setleft(Insert(root->Getleft(),name,location,val));
    }
    else if(val > root->Getdata())///if value is greater than
    {
        if(root->GetRight()==NULL)
            root->SetRight(newTreeNode);
        else
            root->SetRight(Insert(root->GetRight(),name,location,val));
    }
    else
    {
        cout<<"No Duplication Is Allowed"<<endl;
        return root;
    }

   // root->SetHeight(1+Maximum(Height(root->Getleft()), Height(root->GetRight())));
    ///insertion in avl with avl balance factor
    int BalanceFactor = GetbalanceFactor(root);

    /// L L Rotation
    if(BalanceFactor > 1 && newTreeNode->Getdata() < root->Getleft()->Getdata()) ///left skewt
        return RightRotate(root);

    else if(BalanceFactor < -1 && newTreeNode->Getdata() > root->GetRight()->Getdata())/// R R Rotation ///rigt skewt
        return LeftRotate(root);

    else if(BalanceFactor > 1 && newTreeNode->Getdata() > root->Getleft()->Getdata()) /// L R Rotation
    {
        root->Setleft(LeftRotate(root->Getleft()));
        return RightRotate(root);
    }
    else if(BalanceFactor < -1 && newTreeNode->Getdata() < root->GetRight()->Getdata()) /// R L Rotation
    {
        root->SetRight(RightRotate(root->GetRight()));
        return LeftRotate(root);
    }

    return root;
}


TreeNode* AVLTREE::Search(TreeNode* root , int key)
{
    if(root==NULL)
        return NULL;
    else if(root->Getdata()==key)
        return root;
    else
    {
        if(key<root->Getdata())
            return Search(root->Getleft(),key);
        else
            return Search(root->GetRight(),key);
    }
    return NULL;
}

TreeNode* AVLTREE::DeleteInBst(TreeNode* root , int key)
{
    if(root==NULL)
        return root;
    else if(key < root->Getdata())
    {
        root->Setleft(DeleteInBst(root->Getleft(),key));
    }
    else if(key > root->Getdata())
    {
        root->SetRight(DeleteInBst(root->GetRight(),key));
    }
    else
    {
        if(root->Getleft()==NULL)
        {
            TreeNode* temp = root->GetRight();
             delete root;
             flag = true;
            return temp;

        }
        else if(root->GetRight()==NULL)
        {
            TreeNode* temp = root->Getleft();
            delete root;
            flag = true;
            return temp;

        }
        else if(root->Getleft()==NULL && root->GetRight()==NULL) ///only root case 1 node i.e root node
        {
            TreeNode* ptr = root;
            root = NULL;
            flag = true;
            delete ptr;
        }
        else{
            TreeNode* temp = InOrderSuccessor(root->GetRight());
                root->Setdata(temp->Getdata());
                root->SetRight(DeleteInBst(root->GetRight(),temp->Getdata()));
        }

    }

    ///deletion of node in avl by bf
    int balanceFactor = GetbalanceFactor(root);

    /// L L --> right Rotation
    if(balanceFactor==2 && GetbalanceFactor(root->Getleft()) >= 0 )
        return RightRotate(root);
    else if(balanceFactor==2 && GetbalanceFactor(root->Getleft())==-1) /// Left R --> LR rotation
    {
         root->Setleft(LeftRotate(root->Getleft()));
         return RightRotate(root);
    }
    else if (balanceFactor == -2 && GetbalanceFactor(root->GetRight()) <= 0)/// Right R --> Left rotation
         return LeftRotate(root);
    else if (balanceFactor == -2 && GetbalanceFactor(root->GetRight()) == 1)/// Right L --> RL rotation
    {
          root->SetRight(RightRotate(root->GetRight()));
          return LeftRotate(root);
    }
     return root;
}

int AVLTREE::Frequency(TreeNode* root)
{
    if(root==NULL)
        return 0;

    return 1 + Frequency(root->Getleft())+Frequency(root->GetRight());
}

TreeNode* AVLTREE::updateRecord(TreeNode* root, int key)
{
    TreeNode* ptr = Search(root, key);
    if(ptr!=NULL)
        return ptr;
    else
        return NULL;
}
TreeNode* AVLTREE::InOrderSuccessor(TreeNode* root)
{
    TreeNode* ptr = root;
    while(ptr->Getleft()!=NULL)
    {
        ptr = ptr->Getleft();
    }
    return ptr;
}

TreeNode* AVLTREE::InOrderPredecessor(TreeNode* root)
{
    TreeNode* ptr = root;
    while(ptr->GetRight()!=NULL)
    {
        ptr = ptr->GetRight();
    }
    return ptr;
}
void AVLTREE::InOrder(TreeNode* root)
{
    if(root==NULL)
    {
        return;
    }
    else
        InOrder(root->Getleft());
        cout<<root->Getdata()<<"\t\t\t"<<root->Getname()<<"\t\t\t"<<root->Getlocation()<<endl;
        InOrder(root->GetRight());
}

void AVLTREE::PreOrder(TreeNode* root , fstream& fout)
{
    if(root==NULL)
        return;
    else
    {
        fout<<root->Getname()<<endl;
        fout<<root->Getlocation()<<endl;
        fout<<root->Getdata()<<endl;
        PreOrder(root->Getleft(),fout);
        PreOrder(root->GetRight(),fout);
    }

}

void AVLTREE::PostOrder(TreeNode* root , fstream& fout)
{
    if(root==NULL)
        return;
    else
    {
        PostOrder(root->Getleft(),fout);
        PostOrder(root->GetRight(),fout);      //right
        fout<<root->Getname()<<endl;
        fout<<root->Getlocation()<<endl;
        fout<<root->Getdata()<<endl;
    }

}





void AVLTREE::DeleteTree(TreeNode* root)
{
    if(root==NULL)
        return;

    if(root->Getleft()!=NULL)
    DeleteTree(root->Getleft());
    if(root->GetRight()!=NULL)
    DeleteTree(root->GetRight());

    free(root);
    SetRoot(NULL);
    return;

}

void AVLTREE::printTree(TreeNode* r, int space) {
    if (r == NULL)
      return;
      int SPACE = 10;
    space += SPACE;
    printTree(r->GetRight(), space);
    cout << endl;
    for (int i = SPACE; i < space; i++)
      cout << " ";
    cout << r->Getdata() << "\n";
    printTree(r ->Getleft(), space);
  }

AVLTREE::~AVLTREE()
{
    //dtor
}
