#include "Hashtable.h"
#include "AVLTREE.h"
#include "TreeNode.h"
#include<windows.h>
#include <iostream>
#include<string>
#include <fstream>
#include <sstream>

#define loadfactor 10

using namespace std;

Hashtable::Hashtable()
{
    flag = false;
}
Hashtable::Hashtable(int s)
{
    Size = s;
    arr = new AVLTREE[Size];
    for(int i=0 ; i<Size; i++)
    {
        arr[i].SetRoot(NULL);
        Setfrequency(-1);
    }
}

bool Hashtable::isPrime(int key)      ///check number is prime or not
{

    if (key <= 1)
        return false;
    if (key <= 3)
        return true;

    if (key % 2 == 0 || key % 3 == 0)
        return false;

    for (int i = 5; i * i <= key; i = i + 6)
        if (key % i == 0 || key % (i+2) == 0)
           return false;

    return true;
}


int Hashtable::nextPrime(int key)        ///function which return near prime number
{

    if (key <= 1)
        return 2;

    int prime = key;
    bool found = false;

    while (!found) {
        prime++;

        if (isPrime(prime))
            found = true;
    }

    return prime;
}



int Hashtable::HashFunction(int id)
{
    return id%Size;
}

bool Hashtable::IsBucketFull()
{
    for(int i=0;i<Size;i++)
    {
        int frequency = arr[i].Frequency(arr[i].GetRoot())/Size;

        if(frequency >= loadfactor)
        {
            return true;
        }
    }
    return false;

}

int Hashtable::HashAgain(int key2)
{
    int prime = nextPrime(Size);
    return key2 % prime;
}

AVLTREE* Hashtable::Rehash_Newtable( string name , string loc ,int key)
{

//    int newSize = 2*Size;
//    AVLTREE* newTable = new AVLTREE[newSize];
//    for(int i=0; i<newSize;i++)
//    {
//        if(arr[i]!=arr[i].isepmty()){
//            int index = HashFunction(arr[i]);
//        int i=1;
//        while(newTable[index]!= newTable.isepmty())
//        {
//            index = HashAgain(key);
//        }
//        newTable[index] = arr[i];
//        }
//    }
//    arr = newTable;
//    delete newTable;


    AVLTREE* OLd_array_data = new AVLTREE[Size];        ///for storing old array data

    for(int i=0;i<Size;i++)
    {
        OLd_array_data[i] = arr[i];
    }
    SetSize(Size*2);        ///doubling the size of hashtable

    arr = new AVLTREE[GetSize()];
    cout<<111<<endl;
    for(int i=0;i<Size;i++)
    {
        arr[i] = OLd_array_data[i];  ///copying the old data into same prev array
    }
    delete OLd_array_data;

    return arr;


}

void Hashtable::insertion(string name , string loc , int id)
{
    int index = HashFunction(id);
    if(IsBucketFull()==true)
    {
        arr = Rehash_Newtable(name,loc,id);
        int index2 = HashAgain(id);
        arr[index2].Insert(arr[index2].GetRoot(),name,loc,id);
    }
    else{
        arr[index].Insert(arr[index].GetRoot(),name,loc,id);
    }


}


TreeNode* Hashtable::Search(int val)
{
    int index = HashFunction(val);
        TreeNode* temp = arr[index].Search(arr[index].GetRoot(),val);
    if(temp==NULL)
    {
        int index2 = HashAgain(val);
        TreeNode* temp2 = arr[index2].Search(arr[index].GetRoot(),val);
        if(temp2==NULL)
        return NULL;
        else
            return temp2;
    }
    else
    {
        return temp;
    }

}

void Hashtable::DeleteData(int key)
{
    int index = HashFunction(key);
    if(arr[index].getflag()==false)
    {
        arr[index].DeleteInBst(arr[index].GetRoot(),key);
        arr[index].setbool(false);
    }
    else
    {
        int index2 = HashAgain(key);
        arr[index2].DeleteInBst(arr[index2].GetRoot(),key);
        arr[index2].setbool(false);
    }

}

void Hashtable::UpdateData(int key ,Hashtable& U_obj)
{
    int index = HashFunction(key);
    TreeNode* ptr = arr[index].updateRecord(arr[index].GetRoot(),key);
    if(ptr==NULL)
    {
        int index2 = HashAgain(key);
        ptr = arr[index2].updateRecord(arr[index2].GetRoot(),key);
    }
    if(ptr!=NULL)
    {
        int id;string name , loc;
        bool FLAG = false;
        cout<<"ID\t\t\tNAME\t\t\tLocation"<<endl;
        cout<<ptr->Getdata()<<"\t\t\t"<<ptr->Getname()<<"\t\t\t"<<ptr->Getlocation()<<endl;
        while(1)
        {
            cout<<"\n1.To Update ID\n"
                "2.To Update Name Of Hotel\n"
                "3.To Update Location\n"
                "4.To Return\n";
            int choice;
            cin>>choice;
            if(choice==1)
            {
                cout<<"Enter new ID"<<endl;
                int id;
                cin>>id;
                ptr->Setdata(id);
                cout<<"ID Updated"<<endl;
                FLAG = true;
            }
            else if(choice==2)
            {
                cout<<"Enter new Name"<<endl;
                cin.ignore();
                getline(cin,name);
                ptr->Setname(name);
                cout<<"Name Updated"<<endl;
                FLAG = true;
            }
            else if(choice==3)
            {
                cout<<"Enter new Location"<<endl;
                cin.ignore();
                getline(cin,loc);
                ptr->Setlocation(loc);
                cout<<"Location Updated"<<endl;
                FLAG = true;
            }
            else if(choice==4)
            {
                break;
            }
            else
            {
                cout<<"Press Valid Key"<<endl;
            }
            cout<<"\t\t\t\tUpdating.....!"<<endl;
              char load = 219;
                cout<<"\t\t\t\t\t\t";
                for(int i=0;i<3;i++)
                {
                    cout<<load;
                    Sleep(500);
                }
            system("CLS");
           if(FLAG!=false)
           {
               U_obj.insertion(ptr->Getname(),ptr->Getlocation(),ptr->Getdata());
               TreeNode* temp = Search(ptr->Getdata());
               if(temp!=NULL)
               {
                   temp->Setname(ptr->Getname());temp->Setlocation(ptr->Getlocation());
                   temp->Setdata(ptr->Getdata());
               }

           }
            cout<<"\nData Updated"<<endl;
        }
    }
    else
    {
        cout<<"No Data Found "<<endl;
    }
}

void Hashtable::DeleteAllRecord()
{
    for(int i=0;i<Size;i++)
    {
        arr[i].DeleteTree(arr[i].GetRoot());
    }
}

void Hashtable::load_file()///loading data from file
{

     string name , loc,s;
                int id;
                char load = 219;

                    cout<<"\n\n\n\n\n\n\n\n\n\n\t\t\t\t\t\tLoading.....!"<<endl;
                    cout<<"\t\t\t\t\t\t";
                    for(int i=0;i<5;i++)
                    {
                        cout<<load;
                        Sleep(500);
                    }

                    system("CLS");
                    fstream fin("Record.txt");
                    while(!fin.eof())
                    {
                        getline(fin,name);
                        getline(fin,loc);
                        getline(fin,s);
                        std::istringstream(s)>>id;
                        insertion(name,loc,id);
                    }
                    cout<<"List successfully loaded....!"<<endl;
                    fin.close();

}

void Hashtable::write_file(fstream& fout)
{
        for(int i=0;i<Size;i++)
            arr[i].PostOrder(arr[i].GetRoot(),fout);
        cout<<"\n\n\n\n\n\n\n\n\n\n\t\t\t\t\t\tSaving Data.....!"<<endl;
        char load = 219;
        cout<<"\t\t\t\t\t\t";
        for(int i=0;i<3;i++)
        {
            cout<<load;
            Sleep(500);
        }
            system("CLS");
            cout<<"\t\t\t\t\t\tDATA SAVED SUCESSFULLY IN FILE"<<endl;
}

bool Hashtable::isempty()
{
    for(int i=0;i<Size;i++)
    {
        if(arr[i].Frequency(arr[i].GetRoot())==0)
            return true;
        else
            return false;
    }
}


void Hashtable::display()
{
    for(int i=0;i<Size;i++)
    {
        if(arr[i].Frequency(arr[i].GetRoot())!=0){
            arr[i].InOrder(arr[i].GetRoot());
        }
        else
            continue;

    }
}

void Hashtable::printTree()
{
    for(int i=0;i<Size;i++)
    {
        arr[i].printTree(arr[i].GetRoot(),5);

        cout<<"\n\n\n\n"<<endl;
    }
}
Hashtable::~Hashtable()
{
    //dtor
}
