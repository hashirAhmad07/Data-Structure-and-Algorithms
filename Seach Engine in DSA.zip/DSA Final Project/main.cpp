#include <iostream>
#include <fstream>
#include <conio.h>
#include <windows.h>
#include "TreeNode.h"
#include "AVLTREE.h"
#include "hashtable.h"
using namespace std;


void top()
{
    system("CLS");
    cout<<"\t\t\t\t\tSEARCH ENGINE FINAL PROJECT DSA\n\t\t\t\t\t   ~~MADE BY HASHIR AHMED~~ \t\t\t\t       ~~Teacher~~\n\t\t\t\t\t      ~~Travelholic.Pk~~ \t\t\t\t   ~~Sir Zeeshan Khan~~"<<endl;
    cout<<"\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd"<<endl;

}

void loading()
{
    char load = 219;
    cout<<"\t\t\t\t\t\t";
    for(int i=0;i<3;i++)
    {
        cout<<load;
        Sleep(500);
    }
}
int main()
{
    system("color 06");
    Hashtable obj(50);   /// FOR ALL MAIN OPERATIONS
    Hashtable I_obj(50); /// FOR NEW ENTERED DATA LIST
    Hashtable D_obj(50); /// FOR DELETED DATA LIST
    Hashtable U_obj(50); /// FOR UPDATED LIST
    bool flag=0;                    ///for checking data is loaded from file or not
    cout<<"\n\n\n\n\n\n\n\n\n\t\t\t\t\tSEARCH ENGINE FINAL PROJECT DSA\n\t\t\t\t\t   ~~MADE BY HASHIR AHMED~~\n\t\t\t\t\t      ~~Travelholic.Pk~~"<<endl;
    cout<<"\n\n\n\t\t\t\t\t\tStarting.....!"<<endl;
    loading();
    top();
    int i=2;


    string username="admin"; int password=123;
    cout<<"\n\n\n\n\n\n\n\n\n\t\t\t\t\tUserName:";
    cin>>username;
    cout<<"\n\t\t\t\t\tPassword:";
    cin>>password;
    if(username=="admin" && password==123)
    {
        system("CLS");
        top();
       obj.load_file();
        int key;
   while(1)
   {
       system("CLS");
       top();
       cout << "\n \t|      ~~Main MENU~~ \t  |"
				"\n \t|  =>1. For Menu \t  |"
				"\n \t|  =>2. For Saving Data   |"
				"\n \t|  =>3. For Daily opertion|"
				"\n \t|  =>4. For Exit          |\n";
       cout<<"\tPress key___";
       cin>>key;
       switch(key)
       {
           case 1:          ///Menu having different functionalities in it
            {


                 while(1)
                 {
                     top();
                     cout<<"\t\t|           ~~MENU~~  \t\t  |"<<endl;
                     cout<<"\t\t|  =>1.PRESS 1 TO INSERT\t  |\n"
                           "\t\t|  =>2.PRESS 2 TO DELETE RECORD   |\n"
                           "\t\t|  =>3.PRESS 3 TO UPDATE RECORD   |\n"
                           "\t\t|  =>4.PRESS 4 TO SEARCH \t  |\n"
                           "\t\t|  =>5.PRESS 5 TO VIEW DATA\t  |\n"
                           "\t\t|  =>6.PRESS 6 TO DELETE ALLRECORD|\n"
                           "\t\t|  =>7.PRESS 7 TO RETURN MAIN MENU|\n";
                int option;
                cout<<"\t\tPress key__";
                cin>>option;
                if(option==1)           ///INSERTING DATA
                {
                    top();
                    cout<<"NEW DATA ENTERING IN RECORD.......!"<<endl;
                    string name , location;int id;
                    cout<<"ENTER NAME OF HOTEL"<<endl;
                    cin.ignore();
                    getline(cin,name);
                    cout<<"ENTER LOCATION OF HOTEL"<<endl;
                    getline(cin,location);
                    cout<<"Enter ID"<<endl;
                    cin>>id;
                    if(obj.Search(id)==NULL)
                    {
                         obj.insertion(name,location,id);         ///combine list insertion
                         cout<<"SUCESSFULLY INSERTED....! Press any key to continue"<<endl;
                         I_obj.insertion(name,location,id);       ///separate new enteries data list
                         getch();
                    }
                    else{
                        cout<<"NAME ALREADY EXIST.....!No dUPLICATION IS ALLOWED"<<endl;
                        getch();
                    }

                }
                else if(option==2)          ///DELETING DATA
                {
                    top();
                    int id;
                    cout<<"ENTER ID TO DELETE DATA "<<endl;
                    cin>>id;
                    TreeNode* ptr =obj.Search(id);
                    if(ptr!=NULL)
                    {
                        cout<<"ID\t\t\tName\t\t\tLocation"<<endl;
                        cout<<ptr->Getdata()<<"\t\t\t"<<ptr->Getname()<<"\t\t\t"<<ptr->Getlocation()<<endl;
                        cout<<"Do you want to Keep Save Deleted Record( yes | no )"<<endl;
                        string choice;
                        cin>>choice;
                        if(choice=="yes" || choice=="Yes" || choice=="YES" )
                        {

                            D_obj.insertion(ptr->Getname(),ptr->Getlocation(),ptr->Getdata());
                            //loading();
                            fstream fout("DeletedBackup.txt");
                            D_obj.write_file(fout);
                            fout.close();
                            top();
                            cout<<"Record Deleted....And Record Backup Sucessfully Stored"<<endl;
                        }

                    }
                    else
                    {
                        cout<<"No Record Found "<<endl;
                    }

                    obj.DeleteData(id);
                     cout<<"Record Deleted"<<endl;
                    cout<<"Press any key to continue...";
                    getch();
                }
                else if(option==3)          ///UPDATING DATA
                {
                    top();
                    int id;
                    cout<<"ENTER HOTEL ID: "<<endl;
                    cin>>id;
                    obj.UpdateData(id,U_obj);
                    cout<<"Press any key to continue...";
                    getch();
                }
                else if(option==4)          ///SEARCHING DATA
                {
                    top();
                    int id;
                    cout<<"ENTER ID: "<<endl;
                    cin>>id;
                    char load = 219;
                    cout<<"\n\n\n\n\n\n\n\n\n\n\t\t\t\t\t\tSearching.....!"<<endl;
                    loading();
                    top();
                    TreeNode* ptr = obj.Search(id);

                    if(ptr!=NULL)
                    {
                        cout<<"ID\t\t\tHotelName\t\t\tLocation"<<endl;
                        cout<<ptr->Getdata()<<"\t\t\t"<<ptr->Getname()<<"\t\t\t"<<ptr->Getlocation()<<endl;
                        cout<<"Record Exist"<<endl;
                    }

                    else
                        cout<<"Record Doesn't Exist"<<endl;

                    cout<<"Press any key to continue...";
                    getch();
                 }


                else if(option==5)          ///VIEW LIST
                {
                     top();
                     cout<<"ID\t\t\tHotelName\t\t\tLocation"<<endl;
                     obj.display();

                     cout<<"Press any key to continue...";
                     getch();

                }
                else if(option==6)///deleting tree ( all data )
                {
                    top();

                        cout<<"\n\n\n\n\n\n\n\n\n\n\t\t\t\t\t\tDeleting.....!"<<endl;
                        loading();
                        system("CLS");
                        obj.DeleteAllRecord();
                        top();
                        cout<<"Record Deleted"<<endl;


                    cout<<"Press any key to continue...";
                     getch();
                }
                else if(option==7)
                {
                    top();
                    break;
                }
                else
                {
                    cout<<"Press Valid Key"<<endl;
                   top();

                }

                }
                break;
            }
           case 2:          ///SAVING DATA
            {
                top();
                fstream fout("Record.txt");
                obj.write_file(fout);
                fout.close();
                cout<<"Press any key to continue"<<endl;
                getch();
                break;
            }
           case 3:          ///DAILY OPERATION DETAIL
            {
                while(2)
                {
                    top();
                cout << "\n \t|            ~~MENU~~ \t \t |"
                        "\n \t|  =>1. For New Entries \t |"
                        "\n \t|  =>2. For Deleted Record List  |"
                        "\n \t|  =>3. For Updated Record list  |"
                        "\n \t|  =>4. For Return Menu Main     |\n";
				int key1;
				cout<<"\tPress key___";
                cin>>key1;
				if(key1==1)         ///FOR NEW RECORDS ENTERED
                {
                    cout<<"\n\n\n\n\n\n\n\n\n\n\t\t\t\t\t\tProceeding.....!"<<endl;
                    loading();
                    top();
                    cout<<"\nNew Entries List"<<endl;
                    cout<<"ID\t\t\tName\t\t\tLocation"<<endl;
                    I_obj.display();
                    cout<<"Press any key to continue...";
                    getch();
                }
                else if(key1==2)        ///FOR DELETED RECORD BACKUP
                {
                    cout<<"\n\n\n\n\n\n\n\n\n\n\t\t\t\t\t\tProceeding.....!"<<endl;
                    loading();
                    top();
                    cout<<"\nDeleted Record"<<endl;
                    cout<<"ID\t\t\tName\t\t\tLocation"<<endl;
                    D_obj.display();
                    while(3)
                    {
                        cout << "\n \t|  =>1. For Delete All      |"
                                "\n \t|  =>2. For Delete Specific |"
                                "\n \t|  =>3. For Main Menu       |\n";
                        cout<<"\tPress key___";
                        int key3;
                        cin>>key3;

                        if(key3==1)         ///deleting all records backup file deleted here
                        {
                            top();
                            cout<<"\n\n\n\n\n\n\n\n\n\n\t\t\t\t\t\tDeleting Records.....!"<<endl;
                            loading();
                            top();

                            D_obj.DeleteAllRecord();
                            cout<<"\nBackup Deleted"<<endl;
                            cout<<"Press any key to continue...";
                            getch();
                        }
                        if(key3==2)         ///deleting specific data from file
                        {

                            top();
                            string name , location;int id;

                                cout<<"ENTER ID: "<<endl;
                                cin>>id;
                                char load = 219;
                                cout<<"\n\n\n\n\n\n\n\n\n\n\t\t\t\t\t\tProceeding....!"<<endl;
                                loading();
                                top();
                                D_obj.DeleteData(id);
                                cout<<"Record Deleted"<<endl;

                            cout<<"Press any key to continue...";
                            getch();
                        }
                        if(key3==3)     ///return towards main menu
                        {
                            break;
                        }
                    }
                }

                else if(key1==3)        ///UPDATED RECORD LIST
                {
                    cout<<"\n\n\n\n\n\n\n\n\n\n\t\t\t\t\t\tProceeding.....!"<<endl;
                    loading();
                    top();
                    cout<<"\nUpdated Record"<<endl;
                    cout<<"ID\t\t\tName\t\t\tLocation"<<endl;
                    U_obj.display();
                    cout<<"Press any key to continue...";
                    getch();
                }
                else if(key1==4)        ///RETURNS TOWARD MAIN MENU
                {
                    break;
                }
                else
                {
                    cout<<"Press valid key"<<endl;
                }
            }

                break;
            }
           case 4:
            {
                top();
                fstream fout("Record.txt");
                obj.write_file(fout);
                fout.close();
                return 0;
                break;
            }
           default:
                cout<<"Plz Press Valid Key"<<endl;
       }

    }
    }
   else
   {
       cout<<"Wrong password"<<endl;
   }

    return 0;
}

