#ifndef AVLTREE_H
#define AVLTREE_H

#include<fstream>
#include<iostream>
using namespace std;

#include"TreeNode.h"

class AVLTREE
{
    public:
        AVLTREE();
        virtual ~AVLTREE();

        TreeNode* GetRoot() { return Root; }
        void SetRoot(TreeNode* val) { Root = val; }
        TreeNode* Insert(TreeNode*,string ,string,int);     ///insertion
        TreeNode* Search(TreeNode*,int);                    ///searching
        TreeNode* InOrderSuccessor(TreeNode*);              ///successor
        TreeNode* InOrderPredecessor(TreeNode*);            ///predeccessor
        TreeNode* DeleteInBst(TreeNode*,int);               ///deleteinbst
        TreeNode* updateRecord(TreeNode*,int);///, Hashtable&);
        int HieghtInBST(TreeNode*); ///Hieght of tree
        int Maximum(int,int);
        int Height(TreeNode*);
        bool isepmty();
        TreeNode* Swapchild(TreeNode*);
        TreeNode* LeftRotate(TreeNode*);
        TreeNode* RightRotate(TreeNode*);
        int GetbalanceFactor(TreeNode*);
        void DeleteTree(TreeNode*);                         ///deleting whole tree at once
        void loaddata(AVLTREE&);
        void writedata(AVLTREE&);
        void InOrder(TreeNode*);
        void PreOrder(TreeNode*,fstream&);
        void PostOrder(TreeNode*,fstream&);
        void printTree(TreeNode*,int);

        int Frequency(TreeNode*);
        void setbool(bool n){flag=n;}
        bool getflag(){return flag;}
        void Setfrquency(int val){frequency=val;}
        int Getfrequency(){return frequency;}
    protected:

    private:
        TreeNode* Root;
        bool flag;
        int frequency;
};

#endif // AVLTREE_H
